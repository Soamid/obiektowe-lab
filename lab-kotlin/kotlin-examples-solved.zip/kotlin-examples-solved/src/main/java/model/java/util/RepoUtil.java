package model.java.util;

import model.java.Address;
import model.java.Person;

import java.text.Normalizer;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;


public class RepoUtil {

    public static String getFullName(Person person) {
        return String.format("%s %s", person.getName(), person.getSurname());
    }

    public static String removePolishCharacters(String text) {
        var normalizedText = Normalizer.normalize(text, Normalizer.Form.NFD);
        return normalizedText.replaceAll("\\p{M}", "");
    }

    public static List<Address> withFilledCity(List<Address> addresses) {
        return addresses.stream()
                .filter(address -> address.getCity() != null)
                .collect(Collectors.toList());
    }

    public static <T> void logInfo(T object) {
        System.out.println(String.format("%s : object info = %s", LocalDate.now(), object));
    }

}
