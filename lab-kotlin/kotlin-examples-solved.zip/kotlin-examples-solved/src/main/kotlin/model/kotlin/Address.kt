package model.kotlin

data class Address(
    val street: String? = null,
    val city: String? = null,
    val postalCode: String? = null,
    val province: String? = null,
    val details: String? = null
)