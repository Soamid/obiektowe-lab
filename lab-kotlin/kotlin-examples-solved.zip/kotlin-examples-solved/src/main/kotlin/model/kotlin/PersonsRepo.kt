package model.kotlin

import model.kotlin.util.fullName


class PersonsRepo {

    private val persons: MutableList<Person> = mutableListOf()

    fun registerPerson(person: Person) {
        persons.add(person)
    }

    fun getAllSurnames() = persons.asSequence()
            .map { it.surname }
            .distinct()
            .sorted()
            .toList()

    override fun toString() = persons.toString()

    fun findByFullName(fullName: String) : Person? {
       return persons.find { it.fullName() == fullName }
    }
}
