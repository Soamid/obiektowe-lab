package model.java;

public class AddressBuilder {

    private String street;

    private String city;

    private String postalCode;

    private String province;

    private String details;

    public AddressBuilder street(String street) {
        this.street = street;
        return this;
    }

    public AddressBuilder city(String city) {
        this.city = city;
        return this;
    }

    public AddressBuilder postalCode(String postalCode) {
        this.postalCode = postalCode;
        return this;
    }

    public AddressBuilder province(String province) {
        this.province = province;
        return this;
    }

    public AddressBuilder details(String details) {
        this.details = details;
        return this;
    }

    public Address build() {
        return new Address(street, city, postalCode, province, details);
    }
}
