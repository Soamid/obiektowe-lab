package model.java;

import java.util.Optional;

public class Address {

    private final String street;

    private final String city;

    private final String postalCode;

    private final String province;

    private final String details;

    public Address(String street, String city, String postalCode, String province, String details) {
        this.street = street;
        this.city = city;
        this.postalCode = postalCode;
        this.province = province;
        this.details = details;
    }

    public Optional<String> getStreet() {
        return Optional.ofNullable(street);
    }

    public Optional<String> getCity() {
        return Optional.ofNullable(city);
    }

    public Optional<String> getPostalCode() {
        return Optional.ofNullable(postalCode);
    }

    public Optional<String> getProvince() {
        return Optional.ofNullable(province);
    }

    public Optional<String> getDetails() {
        return Optional.ofNullable(details);
    }

    public static AddressBuilder builder() {
        return new AddressBuilder();
    }

    @Override
    public String toString() {
        return "Address{" +
                "street='" + street + '\'' +
                ", city='" + city + '\'' +
                ", postalCode='" + postalCode + '\'' +
                ", province='" + province + '\'' +
                ", details='" + details + '\'' +
                '}';
    }
}
