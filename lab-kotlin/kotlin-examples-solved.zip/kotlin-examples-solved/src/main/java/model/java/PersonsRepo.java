package model.java;

import model.java.util.RepoUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

public class PersonsRepo {

    private final List<Person> persons = new ArrayList<>();

    public void registerPerson(Person person) {
        persons.add(person);
    }

    public List<String> getAllSurnames() {
        return persons.stream()
                .map(Person::getSurname)
                .distinct()
                .sorted()
                .collect(Collectors.toList());
    }

    public Optional<Person> findByFullName(String fullName) {
        return persons.stream()
                .filter(person -> Objects.equals(RepoUtil.getFullName(person), fullName))
                .findFirst();
    }

    @Override
    public String toString() {
        return persons.toString();
    }
}
